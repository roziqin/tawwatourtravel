<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing DeleteCustomerShippingAddressResponse
 */
class DeleteCustomerShippingAddressResponse extends ANetApiResponseType
{


}

